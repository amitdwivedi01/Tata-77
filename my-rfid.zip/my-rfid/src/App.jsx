import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import bg from './assets/bg.jpg';

function App() {
  const [name, setName] = useState('');

  useEffect(() => {
    const socket = io('http://localhost:5000'); // Replace 'backend/socket' with your actual WebSocket server URL

    socket.on('updateNames', updatedName => {
      setName(updatedName);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div
      className="relative h-screen flex justify-center items-center"
      style={{
        backgroundImage: `url(${bg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      {/* <div className="absolute top-0 left-0 right-0 bottom-0"></div> */}
      <div className="z-10 text-white text-center">
        <h1 className="text-4xl mb-4 text-[#daa000] font-bold ">Welcome to Our App! {name}</h1>
      </div>
    </div>
  );
}

export default App;
